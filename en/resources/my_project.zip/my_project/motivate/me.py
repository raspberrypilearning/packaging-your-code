def motivate_me():
    print("you are doing great, keep it up")