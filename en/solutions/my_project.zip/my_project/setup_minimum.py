from setuptools import setup

__project__ = "motivate"
__version__ = "0.0.1"
__description__ = "a python module to motivate you"
__packages__ = ["motivate"]

setup(
    name = __project__,
    version = __version__,
    description = __description__,
    packages = __packages__,
)