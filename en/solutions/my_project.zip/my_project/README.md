# Motivate

A test project used in the Raspberry Pi project [Packaging your code](https://projects.raspberrypi.org/en/projects/packaging-your-code).